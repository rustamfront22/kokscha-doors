<script setup>
import { companyContent } from "@/content/companyContent";
import HeroSimple from "@/components/sections/HeroSimple.vue";
import StatsRow from "@/components/sections/StatsRow.vue";
import InfoSection from "@/components/sections/InfoSection.vue";
import BenefitGrid from "@/components/sections/BenefitGrid.vue";
import Steps from "@/components/sections/Steps.vue";
import LeadForm from "@/components/views/home/LeadForm.vue";
</script>

<template>
  <div class="min-h-screen">
    <HeroSimple
      :title="companyContent.builders.heroTitle"
      :subtitle="companyContent.builders.heroSubtitle"
      ctaText="Оставить заявку"
      ctaTo="#lead-form"
    />

    <StatsRow :items="companyContent.stats" />

    <InfoSection
      :title="companyContent.builders.qualityTitle"
      :text="[companyContent.builders.qualityText]"
      :bullets="companyContent.builders.points"
    />

    <BenefitGrid
      :title="companyContent.benefits.title"
      :items="companyContent.benefits.items"
    />

    <Steps
      :title="companyContent.process.title"
      :steps="companyContent.process.steps"
      :finish="companyContent.process.finish"
    />

    <LeadForm />
  </div>
</template>