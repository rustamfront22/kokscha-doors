<template>
  <div class="home-page">
    <CarouselMain/>
    <NewProducts />
    <AllProducts />
    <LeadForm />
    <CarouselFooter />
    <Partners />
    <StatsRow :items="companyContent.stats" />
  <InfoSection
    :title="companyContent.about.title"
    :text="companyContent.about.text"
    :bullets="companyContent.about.bullets"
  />
  <BenefitGrid :title="companyContent.benefits.title" :items="companyContent.benefits.items" />
  <Steps :title="companyContent.process.title" :steps="companyContent.process.steps" :finish="companyContent.process.finish" />

  
  </div>
</template>
<script setup>
import NewProducts from "../components/views/home/NewProducts.vue";
import AllProducts from "../components/views/home/AllProducts.vue";
import CarouselFooter from "../components/views/home/CarouselFooter.vue";
import Partners from "../components/views/home/Partners.vue";
import LeadForm from "../components/views/home/LeadForm.vue";
import CarouselMain from "../components/views/home/CarouselMain.vue";
import { companyContent } from "@/content/companyContent";
import StatsRow from "@/components/sections/StatsRow.vue";
import InfoSection from "@/components/sections/InfoSection.vue";
import BenefitGrid from "@/components/sections/BenefitGrid.vue";
import Steps from "@/components/sections/Steps.vue";

</script>