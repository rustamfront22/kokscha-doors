<template>
  <section class="partners">
    <div class="container">

      <div class="partners__header">
        <h1 class="title">Нам доверяют</h1>
        <p>
          Мы сотрудничаем с крупными брендами, бизнес-центрами и
          архитектурными студиями в Узбекистане и за его пределами.
        </p>
      </div>

      <div class="partners__grid">
        <div
          v-for="(item, index) in partners"
          :key="index"
          class="partner-card"
        >
          <div class="partner-card__inner">
            <span>{{ item }}</span>
          </div>
        </div>
      </div>

    </div>
  </section>
</template>

<script setup>
const partners = [
  "Hydrolife",
  "Yoshlar TV",
  "Otto Turk",
  "Abi Atel",
  "Novias Plaza",
  "Al Anvar",
  "Rekable",
  "Stoffa",
  "Comfort Textile"
];
</script>

<style scoped>
.partners {
  min-height: 100vh;
  padding: 120px 0;
  background: var(--bg);
}

.partners__header {
  text-align: center;
  max-width: 800px;
  margin: 0 auto 80px;
}

.partners__header h1 {
  font-size: clamp(36px, 4vw, 64px);
  margin-bottom: 16px;
}

.partners__header p {
  color: var(--muted);
  font-size: 18px;
  line-height: 1.6;
}

.partners__grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 28px;
}

/* КАРТОЧКА */
.partner-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 20px;
  padding: 40px 20px;
  transition: all .4s cubic-bezier(.2,.6,.2,1);
  box-shadow: 0 10px 30px rgba(0,0,0,.05);
  position: relative;
  overflow: hidden;
}

.partner-card::before {
  content: "";
  position: absolute;
  inset: 0;
  background: radial-gradient(circle at 50% 0%, rgba(200,161,101,.12), transparent 70%);
  opacity: 0;
  transition: .4s;
}

.partner-card:hover {
  transform: translateY(-8px);
  border-color: rgba(200,161,101,.55);
  box-shadow: 0 25px 60px rgba(0,0,0,.08);
}

.partner-card:hover::before {
  opacity: 1;
}

.partner-card__inner {
  font-weight: 700;
  font-size: 18px;
  letter-spacing: .5px;
}
</style>