<script setup>
import { companyContent } from "@/content/companyContent";
import HeroSimple from "@/components/sections/HeroSimple.vue";
import LeadForm from "@/components/views/home/LeadForm.vue";
</script>

<template>
  <div class="min-h-screen">
    <HeroSimple
      :title="companyContent.designers.heroTitle"
      :subtitle="companyContent.designers.heroSubtitle"
      ctaText="Оставить заявку"
      ctaTo="#lead-form"
    />

    <section class="py-12">
      <div class="container">
        <div class="grid md:grid-cols-2 gap-4">
          <div
            v-for="(b, i) in companyContent.designers.blocks"
            :key="i"
            class="rounded-2xl bg-white/5 border border-white/10 p-6"
          >
            <div class="text-xl font-semibold">{{ b.title }}</div>
            <p class="opacity-85 mt-2">{{ b.text }}</p>
          </div>
        </div>
      </div>
    </section>

    <LeadForm />
  </div>
</template>