<script setup>
const props = defineProps({
  title: { type: String, default: "" },
  text: { type: Array, default: () => [] },
  bullets: { type: Array, default: () => [] },
});
</script>

<template>
  <section class="py-12">
    <div class="container">
      <div class="grid md:grid-cols-2 gap-8 items-start">
        <div>
          <h2 class="text-2xl md:text-3xl font-bold">{{ title }}</h2>
          <div class="mt-4 space-y-3 opacity-90">
            <p v-for="(p, i) in text" :key="i">{{ p }}</p>
          </div>
        </div>

        <ul class="grid gap-3">
          <li
            v-for="(b, i) in bullets"
            :key="i"
            class="rounded-xl bg-white/5 border border-white/10 p-4"
          >
            • {{ b }}
          </li>
        </ul>
      </div>
    </div>
  </section>
</template>