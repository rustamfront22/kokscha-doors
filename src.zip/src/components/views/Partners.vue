<script setup>
import { companyContent } from "@/content/companyContent";
import HeroSimple from "@/components/sections/HeroSimple.vue";
import InfoSection from "@/components/sections/InfoSection.vue";
import StatsRow from "@/components/sections/StatsRow.vue";
import LeadForm from "@/components/views/home/LeadForm.vue";
</script>

<template>
  <div class="min-h-screen">
    <HeroSimple
      :title="companyContent.partnership.heroTitle"
      :subtitle="companyContent.partnership.heroSubtitle"
      ctaText="Оставить заявку"
      ctaTo="#lead-form"
    />

    <StatsRow :items="companyContent.stats" />

    <InfoSection
      title="Преимущества фабрики"
      :text="[]"
      :bullets="companyContent.partnership.factoryBenefits"
    />

    <InfoSection
      title="Почему необходимо участвовать"
      :text="[]"
      :bullets="companyContent.partnership.why"
    />

    <InfoSection
      title="Что предполагает программа"
      :text="[]"
      :bullets="companyContent.partnership.program"
    />

    <!-- форма -->
    <LeadForm />
  </div>
</template>