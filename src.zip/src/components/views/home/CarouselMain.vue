<template>
  <section class="hero">
    <div class="hero__media">
      <video
        class="hero__video"
        autoplay
        muted
        loop
        playsinline
        preload="metadata"
      >
        <source src="/video/hero.mp4" type="video/mp4" />
      </video>
      <div class="hero__overlay"></div>
    </div>

    <div class="hero__inner">
      <div class="container hero__content">
        <div class="hero__grid">
          <!-- LEFT -->
          <div class="hero__left">
            <div class="hero__kicker">kokscha doors</div>
            <div class="hero__subkicker">Официальный сайт фабрики</div>

            <h1 class="hero__title">Двери <span>&</span> Интерьер</h1>

            <p class="hero__facts">
              4+ лет на рынке · 200+ моделей · 500+ вариантов отделки · Подбор,
              доставка, установка под ключ
            </p>

            <div class="hero__actions">
              <a class="hero__phone" href="tel:+998900000000"
                >+998 90 000 00 00</a
              >

              <RouterLink :to="{ name: 'products' }" class="btn btn-primary">
                Каталог
              </RouterLink>

              <a href="#lead-form" class="btn btn-outline">Оставить заявку</a>
            </div>

            <!-- цифры как у Geona -->
            <div class="hero__stats">
              <div class="stat">
                <div class="stat__num">7</div>
                <div class="stat__label">лет гарантии</div>
              </div>

              <div class="stat">
                <div class="stat__num">200+</div>
                <div class="stat__label">моделей</div>
              </div>

              <div class="stat">
                <div class="stat__num">500+</div>
                <div class="stat__label">цветов/отделок</div>
              </div>
            </div>
          </div>

          <!-- RIGHT (можно оставить пустым или под форму/картинку) -->
          <div class="hero__right"></div>
        </div>
      </div>
    </div>
  </section>
</template>

<script setup></script>

<style scoped>
.hero{
  position: relative;
  min-height: 100vh;
  overflow: hidden;
}

/* место под sidebar только на больших */
.hero__inner{
  min-height: 100vh;
  padding-left: var(--side-w);
  display: flex;
  align-items: center;
}

@media (max-width: 1024px){
  .hero__inner{ padding-left: 72px; }
}
@media (max-width: 768px){
  .hero__inner{ padding-left: 0; }
}

.hero__media{
  position:absolute;
  inset:0;
  z-index:0;
  background:#eee;
}

.hero__video{
  width:100%;
  height:100%;
  object-fit:cover;
}

/* ✅ делаем overlay аккуратным (и не “туман” на весь экран) */
.hero__overlay{
  position:absolute;
  inset:0;

  background: linear-gradient(
    90deg,
    rgba(255,255,255,0.95) 0%,
    rgba(255,255,255,0.88) 2%,
    rgba(255,255,255,0.55) 20%,
    rgba(255,255,255,0.18) 67%,
    rgba(255,255,255,0) 75%
  );
}

/* ✅ контент */
.hero__content{
  position:relative;
  z-index:2;
  padding: 90px 0 60px;
  color:#111;
}

@media (max-width: 768px){
  .hero__content{ padding: 84px 0 42px; }
}

.hero__kicker{
  text-transform: uppercase;
  letter-spacing: 0.28em;
  font-weight: 600;
  font-size: 12px;
  color:#111;
  opacity:.75;
  margin-bottom: 8px;
}

.hero__subkicker{
  font-size: 14px;
  color:#111;
  opacity:.75;
  margin-bottom: 14px;
}

.hero__title{
  font-family:"Playfair Display", serif;
  font-weight: 700;
  font-size: clamp(38px, 5vw, 72px);
  line-height: 1.05;
  margin-bottom: 14px;
}

.hero__facts{
  max-width: 680px;
  font-size: 16px;
  line-height: 1.65;
  color: rgba(17,17,17,.68);
  margin-bottom: 22px;
}

.hero__actions{
  display:flex;
  align-items:center;
  gap: 12px;
  flex-wrap: wrap;
  margin-bottom: 22px;
}

/* ✅ чтобы кнопки не растягивались */
.hero__actions .btn{
  display:inline-flex;
  width:auto;
}

/* телефон */
.hero__phone{
  font-weight: 700;
  color:#111;
  text-decoration:none;
  padding: 10px 0;
}
.hero__phone:hover{ text-decoration: underline; }

/* ✅ stats аккуратно */
.hero__stats{
  display:flex;
  gap: 14px;
  flex-wrap: wrap;
}

.stat{
  background:#fff;
  border:1px solid #e7e5e4;
  border-radius: 16px;
  padding: 14px 18px;
  box-shadow: 0 10px 30px rgba(0,0,0,.05);
  min-width: 160px;
}

@media (max-width: 480px){
  .stat{ min-width: 140px; padding: 12px 14px; }
}

.stat__num{ font-size: 28px; font-weight: 800; }
.stat__label{
  font-size: 12px;
  letter-spacing: .12em;
  text-transform: uppercase;
  color: rgba(17,17,17,.55);
}
.hero__media,
.hero__video,
.hero__overlay{
  pointer-events: none;
}
</style>
