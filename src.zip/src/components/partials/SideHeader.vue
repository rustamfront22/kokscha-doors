<template>
  <!-- ЛЕВАЯ ПАНЕЛЬ -->
  <aside :class="['side', { 'is-hidden': navOpen || formOpen }]">
    <div class="side__top">
      <RouterLink to="/" class="side__logo" @click="closeAll">
        <img
          src="@/assets/img/kokscha_icon_transparent.svg"
          alt="logo"
          width="34"
          height="34"
        />
      </RouterLink>

      <!-- Burger -->
      <button class="side__burger" @click="openNav" aria-label="Open menu">
        <span></span><span></span>
      </button>
    </div>

    <div class="side__scroll">
      <svg viewBox="0 0 100 100">
        <circle cx="50" cy="50" r="46" />
      </svg>
      <div class="side__percent">{{ scroll }}%</div>
    </div>

    <!-- Вертикальный текст -->
    <div class="side__label">
      <span>{{ currentLabel }}</span>
    </div>

    <!-- вниз к LeadForm -->
    <div class="side__bottom">
      <button class="side__icon" type="button" @click="scrollToLead" title="scroll">
        ↓
      </button>
    </div>
  </aside>

  <!-- OVERLAY -->
  <transition name="fade">
    <div v-if="navOpen || formOpen" class="overlay" @click="closeAll"></div>
  </transition>

  <!-- МЕНЮ (выезжает слева) -->
  <transition name="slide-left">
    <div v-if="navOpen" class="panel panel--nav">
      <div class="panel__head">
        <div class="panel__title">Меню</div>
        <button class="panel__close" @click="closeAll" aria-label="Close">
          ✕
        </button>
      </div>

      <nav class="panel__nav">
        <RouterLink @click="closeAll" :to="{ name: 'index' }">Главная</RouterLink>
        <RouterLink @click="closeAll" :to="{ name: 'products' }">Каталог</RouterLink>
        <RouterLink @click="closeAll" :to="{ name: 'partners' }">Сотрудничество</RouterLink>
        <RouterLink @click="closeAll" :to="{ name: 'designers' }">Дизайнерам</RouterLink>
        <RouterLink @click="closeAll" :to="{ name: 'builders' }">Строителям</RouterLink>
      </nav>

      <div class="panel__footer">
        <button class="btn btn-primary w-full text-center" type="button" @click="scrollToLead">
          Оставить заявку
        </button>

        <a class="btn btn-secondary w-full text-center mt-3" href="tel:+998900000000">
          Позвонить
        </a>
      </div>
    </div>
  </transition>

  <!-- КНОПКА СПРАВА -->
  <button class="contact-fab" @click="openForm">Написать нам</button>

  <!-- ФОРМА (выезжает справа) -->
  <transition name="slide-right">
    <div v-if="formOpen" class="panel panel--form">
      <div class="panel__head">
        <div class="panel__title">Оставить заявку</div>
        <button class="panel__close" @click="closeAll" aria-label="Close">
          ✕
        </button>
      </div>

      <!-- ✅ мини-форма тоже отправляет лид (бек требует length/width) -->
      <form class="form" @submit.prevent="submit">
        <label class="form__field">
          <span>Имя</span>
          <input v-model="name" type="text" placeholder="Ваше имя" required />
        </label>

        <label class="form__field">
          <span>Телефон</span>
          <input
            v-model="phone"
            type="tel"
            placeholder="+998 __ ___ __ __"
            required
          />
        </label>

        <div class="form__row">
          <label class="form__field">
            <span>Длина (см)</span>
            <input v-model="length" type="number" min="1" placeholder="200" required />
          </label>

          <label class="form__field">
            <span>Ширина (см)</span>
            <input v-model="width" type="number" min="1" placeholder="90" required />
          </label>
        </div>

        <label class="form__field">
          <span>Комментарий</span>
          <textarea
            v-model="msg"
            rows="4"
            placeholder="Какая дверь нужна?"
          ></textarea>
        </label>

        <button class="btn btn-primary w-full" type="submit" :disabled="sending">
          <span v-if="!sending">Отправить</span>
          <span v-else>Отправляем…</span>
        </button>

        <p class="form__hint">
          Нажимая «Отправить», вы соглашаетесь на обработку данных.
        </p>

        <p v-if="errorText" class="form__error">
          {{ errorText }}
        </p>

        <p v-if="successText" class="form__success">
          {{ successText }}
        </p>
      </form>
    </div>
  </transition>
</template>

<script setup>
import { computed, onMounted, onUnmounted, ref } from "vue";
import { useRoute } from "vue-router";
import axios from "axios";

const navOpen = ref(false);
const formOpen = ref(false);

const name = ref("");
const phone = ref("");
const msg = ref("");
const length = ref("");
const width = ref("");

const sending = ref(false);
const errorText = ref("");
const successText = ref("");

const route = useRoute();

const currentLabel = computed(() => {
  const map = {
    index: "ГЛАВНАЯ",
    products: "КАТАЛОГ",
    partners: "СОТРУДНИЧЕСТВО",
    designers: "ДИЗАЙНЕРАМ",
    builders: "СТРОИТЕЛЯМ",
  };
  return map[route.name] || "KO'KCHA";
});

const lockScroll = (lock) => {
  document.documentElement.style.overflow = lock ? "hidden" : "";
};

const openNav = () => {
  navOpen.value = true;
  formOpen.value = false;
  lockScroll(true);
};

const openForm = () => {
  formOpen.value = true;
  navOpen.value = false;
  lockScroll(true);
};

const closeAll = () => {
  navOpen.value = false;
  formOpen.value = false;
  lockScroll(false);
};

const onKey = (e) => {
  if (e.key === "Escape") closeAll();
};

// ✅ скролл к большой LeadForm (id="lead-form")
const scrollToLead = () => {
  closeAll();
  requestAnimationFrame(() => {
    document.querySelector("#lead-form")?.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  });
};

// ✅ нормализация телефона: оставляем + и цифры
const normalizePhone = (v) => String(v || "").replace(/[^\d+]/g, "");

// ✅ отправка мини-формы на бек через Vite proxy: POST /api/leads
const submit = async () => {
  errorText.value = "";
  successText.value = "";

  const len = Number(length.value);
  const wid = Number(width.value);

  if (!name.value.trim() || !normalizePhone(phone.value) || !len || !wid) {
    errorText.value = "Заполните имя, телефон, длину и ширину.";
    return;
  }

  sending.value = true;

  try {
    const payload = {
      fullName: name.value.trim(),
      phoneNumber: normalizePhone(phone.value),
      doorType: "Не выбрано",
      length: len,
      width: wid,
      dobor: msg.value || "",
      priorities: ["Качество и надежность", "Цена"],
      source: "website",
      language: "ru",
    };

    await axios.post("/api/leads", payload, {
      headers: { "Content-Type": "application/json" },
    });

    successText.value = "Заявка отправлена ✅";

    name.value = "";
    phone.value = "";
    msg.value = "";
    length.value = "";
    width.value = "";

    setTimeout(() => {
      closeAll();
      successText.value = "";
    }, 900);
  } catch (err) {
    const status = err?.response?.status;
    const data = err?.response?.data;
    console.log("LEAD ERROR:", status, data || err.message);

    errorText.value =
      data?.error ||
      data?.message ||
      "Ошибка отправки. Проверьте данные и попробуйте ещё раз.";
  } finally {
    sending.value = false;
  }
};

const scroll = ref(0);

const updateScroll = () => {
  const h = document.documentElement;
  const scrolled = (h.scrollTop / (h.scrollHeight - h.clientHeight)) * 100;
  scroll.value = Math.round(scrolled || 0);
};

onMounted(() => {
  updateScroll();
  window.addEventListener("scroll", updateScroll, { passive: true });
  window.addEventListener("keydown", onKey);
});

onUnmounted(() => {
  window.removeEventListener("scroll", updateScroll);
  window.removeEventListener("keydown", onKey);
});
</script>

<style scoped lang="scss">
.side__scroll {
  @apply flex flex-col items-center gap-2 mb-6;

  svg {
    width: 60px;
    height: 60px;
    transform: rotate(-90deg);

    circle {
      fill: none;
      stroke: rgba(17, 17, 17, 0.18);
      stroke-width: 3;
      stroke-dasharray: 290;
      stroke-dashoffset: calc(290 - (290 * v-bind(scroll)) / 100);
      transition: 0.2s;
    }
  }

  .side__percent {
    @apply text-xs;
    color: #111;
    opacity: 0.55;
  }
}

/* LEFT SIDE BAR (desktop/tablet) */
.side {
  @apply fixed left-0 top-0 h-screen z-[2000] flex flex-col justify-between;
  width: 84px;
  background: rgba(255, 255, 255, 0.14);
  backdrop-filter: blur(14px);
  -webkit-backdrop-filter: blur(14px);
  border-right: 1px solid rgba(255, 255, 255, 0.28);
}

/* tablet */
@media (max-width: 1024px) {
  .side {
    width: 72px;
  }
}

/* ✅ mobile: sidebar floating */
@media (max-width: 768px) {
  .side {
    width: 64px;
    height: auto;
    top: 12px;
    left: 12px;
    bottom: auto;
    border-right: 0;
    border: 1px solid rgba(0, 0, 0, 0.08);
    background: rgba(255, 255, 255, 0.65);
    backdrop-filter: blur(16px);
    -webkit-backdrop-filter: blur(16px);
    border-radius: 18px;
    padding: 10px 8px;
    gap: 10px;
  }

  .side__top {
    @apply flex flex-col items-center;
    gap: 10px;
    padding-top: 0 !important;
  }

  .side__scroll {
    display: none;
  }
  .side__label {
    display: none;
  }
  .side__bottom {
    display: none;
  }

  .side__logo,
  .side__burger {
    width: 44px;
    height: 44px;
    border-radius: 14px;
    background: rgba(255, 255, 255, 0.9);
    border: 1px solid rgba(0, 0, 0, 0.08);
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
  }

  .side__burger span {
    background: #111;
  }
}

/* buttons inside sidebar */
.side__logo,
.side__burger,
.side__icon {
  background: rgba(255, 255, 255, 0.22);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
}

.side__burger:hover,
.side__icon:hover {
  background: rgba(255, 255, 255, 0.3);
}

.side__burger {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  background: #fff;
  border: 1px solid #e7e5e4;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 8px;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.06);
  cursor: pointer;
  transition: 0.2s ease;
}

.side__burger:hover {
  background: rgba(200, 161, 101, 0.1);
  border-color: rgba(200, 161, 101, 0.55);
}

.side__burger span {
  display: block;
  height: 2px;
  width: 22px;
  border-radius: 999px;
  background: #111;
}
.side__burger span:last-child {
  width: 16px;
}

.side__top {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 14px;
  padding-top: 14px;
}

.side__logo {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  background: #fff;
  border: 1px solid #e7e5e4;
  display: flex;
  align-items: center;
  justify-content: center;
}

.side__label span {
  color: #111;
  opacity: 0.6;
}

.side__icon {
  width: 48px;
  height: 48px;
  border-radius: 14px;
  display: grid;
  place-items: center;
}

/* RIGHT FLOAT BUTTON */
.contact-fab {
  position: fixed;
  right: 24px;
  top: 24px;
  z-index: 55;

  padding: 10px 14px;
  border-radius: 14px;
  font-weight: 700;

  background: #fff;
  border: 1px solid #e7e5e4;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
  transition: 0.2s ease;
}
.contact-fab:hover {
  background: rgba(200, 161, 101, 0.12);
  border-color: rgba(200, 161, 101, 0.55);
}

@media (max-width: 768px) {
  .contact-fab {
    top: auto;
    bottom: 14px;
    right: 14px;
    padding: 10px 12px;
    border-radius: 14px;
    font-size: 14px;
  }
}

/* OVERLAY */
.overlay {
  @apply fixed inset-0 z-[2000];
  background: rgba(0, 0, 0, 0.35);
}

/* PANELS */
.panel {
  @apply fixed top-0 h-screen w-[380px] z-[2001] p-6 flex flex-col;
  background: rgba(255, 255, 255, 0.92);
  backdrop-filter: blur(14px);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.12);
}

@media (max-width: 768px) {
  .panel {
    width: min(92vw, 420px);
    padding: 18px;
  }
}

/* menu left */
.panel--nav {
  left: 0;
  right: auto;
  border-right: 1px solid #e7e5e4;
}

/* form right */
.panel--form {
  right: 0;
  left: auto;
  border-left: 1px solid #e7e5e4;
}

.panel__head {
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.panel__title {
  @apply text-black text-lg font-bold;
}

.panel__close {
  @apply w-10 h-10 rounded-xl transition;
  background: #f5f5f4;
  border: 1px solid #e7e5e4;
  color: #111;
}
.panel__close:hover {
  background: #fff;
}

.panel__nav {
  @apply flex flex-col gap-3 pt-2;

  a {
    padding: 14px 14px;
    border-radius: 14px;
    font-weight: 700;
    color: #111;
    background: #fff;
    border: 1px solid #e7e5e4;
    transition: 0.2s ease;
    text-decoration: none;
  }

  a:hover {
    background: rgba(200, 161, 101, 0.12);
    border-color: rgba(200, 161, 101, 0.55);
  }

  a.router-link-active {
    background: rgba(200, 161, 101, 0.18);
    border-color: rgba(200, 161, 101, 0.65);
  }
}

/* FORM */
.form {
  @apply mt-4 flex flex-col gap-4;
}

.form__row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
}

@media (max-width: 420px) {
  .form__row {
    grid-template-columns: 1fr;
  }
}

.form__field span {
  @apply text-sm font-medium text-black;
  opacity: 0.7;
}

.form__field input,
.form__field textarea {
  @apply w-full rounded-xl px-4 py-3 outline-none;
  background: #fff;
  border: 1px solid #e7e5e4;
  color: #111;
  transition: 0.2s;
}

.form__field input:focus,
.form__field textarea:focus {
  border-color: rgba(200, 161, 101, 0.75);
  box-shadow: 0 0 0 4px rgba(200, 161, 101, 0.18);
}

.form__hint {
  @apply text-xs;
  opacity: 0.6;
}

.form__error {
  @apply text-sm;
  color: #b91c1c;
}

.form__success {
  @apply text-sm;
  color: #15803d;
}

/* Transitions */
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.25s ease;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}

.slide-left-enter-active {
  transition: transform 0.35s ease, opacity 0.35s ease;
}
.slide-left-leave-active {
  transition: transform 0.25s ease, opacity 0.25s ease;
}
.slide-left-enter-from {
  transform: translateX(-18px);
  opacity: 0;
}
.slide-left-enter-to {
  transform: translateX(0);
  opacity: 1;
}
.slide-left-leave-to {
  transform: translateX(-18px);
  opacity: 0;
}

.slide-right-enter-active {
  transition: transform 0.35s ease, opacity 0.35s ease;
}
.slide-right-leave-active {
  transition: transform 0.25s ease, opacity 0.25s ease;
}
.slide-right-enter-from {
  transform: translateX(18px);
  opacity: 0;
}
.slide-right-enter-to {
  transform: translateX(0);
  opacity: 1;
}
.slide-right-leave-to {
  transform: translateX(18px);
  opacity: 0;
}
</style>