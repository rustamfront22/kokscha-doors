<script setup>
import { computed, onMounted, ref } from "vue";
import axios from "axios";

// Backend ждёт:
/// fullName, doorType, measurements, phoneNumber, priorities[], source, language, comment

const props = defineProps({
  doorTypes: {
    type: Array,
    default: () => [
      // value = внутреннее значение, label_ru/uz = отправляемое/показываемое
      { value: "standard", label_ru: "Стандарт", label_uz: "Standart" },
      { value: "premium", label_ru: "Премиум", label_uz: "Premium" },
      { value: "entry", label_ru: "Входная", label_uz: "Kirish" },
      { value: "interior", label_ru: "Межкомнатная", label_uz: "Ichki" },
    ],
  },
});

const lang = ref("ru"); // ru | uz
const API_URL = "/api/leads"; // через vite proxy -> kukcha-backend

const t = computed(() => {
  const dict = {
    ru: {
      title: "Свяжитесь с нами",
      subtitle: "Заполните форму, и мы свяжемся с вами в ближайшее время!",
      fio: "ФИО",
      fioPh: "Введите ФИО",
      door: "Выбранная дверь",
      doorPh: "Выберите тип двери",
      length: "Длина",
      width: "Ширина",
      cm: "см",
      dob: "Добор",
      dobPh: "необязательно",
      important: "Что для вас важнее всего?",
      pick2: "Выберите ровно 2 варианта",
      phone: "Телефон",
      phonePh: "Введите телефон",
      send: "Отправить",
      sending: "Отправляем…",
      req: "Обязательное поле",
      pickExactly2: "Нужно выбрать ровно 2 пункта",
      sentOk: "Заявка отправлена ✅",
      sentFail: "Ошибка отправки. Попробуйте ещё раз.",
    },
    uz: {
      title: "Biz bilan bog‘laning",
      subtitle: "Formani to‘ldiring, tez orada siz bilan bog‘lanamiz!",
      fio: "F.I.SH",
      fioPh: "F.I.SH kiriting",
      door: "Eshik turi",
      doorPh: "Eshik turini tanlang",
      length: "Bo‘yi",
      width: "Eni",
      cm: "sm",
      dob: "Dobor",
      dobPh: "ixtiyoriy",
      important: "Siz uchun eng muhim narsa nima?",
      pick2: "Aniq 2 ta variant tanlang",
      phone: "Telefon",
      phonePh: "Telefon raqamini kiriting",
      send: "Yuborish",
      sending: "Yuborilmoqda…",
      req: "Majburiy maydon",
      pickExactly2: "Aynan 2 ta tanlash kerak",
      sentOk: "So‘rov yuborildi ✅",
      sentFail: "Xatolik. Qayta urinib ko‘ring.",
    },
  };
  return dict[lang.value];
});

// ✅ ВАЖНО: имя должно совпадать с template (v-for="p in priorities")
const priorities = [
  { key: "quality", ru: "Качество и надежность", uz: "Sifat va ishonchlilik" },
  { key: "price", ru: "Цена", uz: "Narx" },
  { key: "design", ru: "Дизайн и стиль", uz: "Dizayn va uslub" },
  { key: "service", ru: "Гарантии и сервис", uz: "Kafolat va servis" },
  {
    key: "security",
    ru: "Надежность и безопасность",
    uz: "Xavfsizlik va mustahkamlik",
  },
];

const form = ref({
  fio: "",
  doorType: "",
  length: "",
  width: "",
  dob: "",
  phone: "",
  priorities: [],
});

const errors = ref({});
const isSubmitting = ref(false);
const toast = ref({ show: false, ok: true, text: "" });
const mounted = ref(false);

onMounted(() => requestAnimationFrame(() => (mounted.value = true)));

const doorLabel = (opt) => (lang.value === "ru" ? opt.label_ru : opt.label_uz);

// телефон: оставляем + и цифры
const normalizePhone = (v) => String(v || "").replace(/[^\d+]/g, "");

// doorType для backend — берём label
const getDoorTypeForBackend = () => {
  const found = props.doorTypes.find((d) => d.value === form.value.doorType);
  if (!found) return "";
  return lang.value === "ru" ? found.label_ru : found.label_uz;
};

// priorities для backend — массив строк
const getPrioritiesForBackend = () => {
  return form.value.priorities.map((k) => {
    const item = priorities.find((p) => p.key === k);
    return item ? (lang.value === "ru" ? item.ru : item.uz) : k;
  });
};

const togglePriority = (key) => {
  const list = form.value.priorities;

  if (list.includes(key)) {
    form.value.priorities = list.filter((x) => x !== key);
    return;
  }
  if (list.length >= 2) return;
  form.value.priorities = [...list, key];
};

const validate = () => {
  const e = {};

  if (!form.value.fio.trim()) e.fio = t.value.req;
  if (!form.value.doorType) e.doorType = t.value.req;

  const len = Number(form.value.length);
  const wid = Number(form.value.width);

  if (!form.value.length || Number.isNaN(len) || len <= 0)
    e.length = t.value.req;
  if (!form.value.width || Number.isNaN(wid) || wid <= 0) e.width = t.value.req;

  const phone = normalizePhone(form.value.phone);
  if (!phone) e.phone = t.value.req;

  if (form.value.priorities.length !== 2) e.priorities = t.value.pickExactly2;

  errors.value = e;
  return Object.keys(e).length === 0;
};

const showToast = (ok, text) => {
  toast.value = { show: true, ok, text };
  setTimeout(() => (toast.value.show = false), 2600);
};

const resetForm = () => {
  form.value = {
    fio: "",
    doorType: "",
    length: "",
    width: "",
    dob: "",
    phone: "",
    priorities: [],
  };
  errors.value = {};
};

const submitLead = async () => {
  if (!validate()) return;

  isSubmitting.value = true;

  try {
    const lengthCm = Number(form.value.length);
const widthCm = Number(form.value.width);

const payload = {
  fullName: form.value.fio,
  phoneNumber: normalizePhone(form.value.phone),
  doorType: getDoorTypeForBackend(),

  length: lengthCm,
  width: widthCm,
  dobor: form.value.dob || "",

  priorities: getPrioritiesForBackend(),
  source: "website",
  language: lang.value,
};

    await axios.post("/api/leads", payload, {
  headers: { "Content-Type": "application/json" },
});

    showToast(true, t.value.sentOk);
    resetForm();
  } catch (err) {
    console.error(
      "LEAD ERROR:",
      err?.response?.status,
      err?.response?.data || err.message
    );
    showToast(false, t.value.sentFail);
  } finally {
    isSubmitting.value = false;
  }
};
</script>

<template>
  <section id="lead-form" class="lead" :class="{ 'is-mounted': mounted }">
    <div class="container">
      <!-- язык -->
      <div class="lead__lang">
        <span class="lead__lang-label">{{
          lang === "ru" ? "язык" : "til"
        }}</span>
        <div class="lead__toggle">
          <button
            type="button"
            class="lead__pill"
            :class="{ active: lang === 'ru' }"
            @click="lang = 'ru'"
          >
            RU
          </button>
          <button
            type="button"
            class="lead__pill"
            :class="{ active: lang === 'uz' }"
            @click="lang = 'uz'"
          >
            UZ
          </button>
        </div>
      </div>

      <div class="lead__card">
        <h2 class="lead__title">{{ t.title }}</h2>
        <p class="lead__subtitle">{{ t.subtitle }}</p>

        <form class="lead__form" @submit.prevent="submitLead">
          <!-- ФИО -->
          <div class="field">
            <label class="label">{{ t.fio }} <span class="req">*</span></label>
            <input
              v-model="form.fio"
              type="text"
              class="input"
              :placeholder="t.fioPh"
              :class="{ invalid: errors.fio }"
            />
            <div v-if="errors.fio" class="error">{{ errors.fio }}</div>
          </div>

          <!-- Тип двери -->
          <div class="field">
            <label class="label">{{ t.door }} <span class="req">*</span></label>
            <select
              v-model="form.doorType"
              class="input"
              :class="{ invalid: errors.doorType }"
            >
              <option value="" disabled>{{ t.doorPh }}</option>
              <option
                v-for="opt in props.doorTypes"
                :key="opt.value"
                :value="opt.value"
              >
                {{ doorLabel(opt) }}
              </option>
            </select>
            <div v-if="errors.doorType" class="error">
              {{ errors.doorType }}
            </div>
          </div>

          <!-- Размеры -->
          <div class="grid2">
            <div class="field">
              <label class="label"
                >{{ t.length }} <span class="req">*</span></label
              >
              <div class="with-suffix">
                <input
                  v-model="form.length"
                  type="number"
                  inputmode="numeric"
                  class="input"
                  :class="{ invalid: errors.length }"
                />
                <span class="suffix">{{ t.cm }}</span>
              </div>
              <div v-if="errors.length" class="error">{{ errors.length }}</div>
            </div>

            <div class="field">
              <label class="label"
                >{{ t.width }} <span class="req">*</span></label
              >
              <div class="with-suffix">
                <input
                  v-model="form.width"
                  type="number"
                  inputmode="numeric"
                  class="input"
                  :class="{ invalid: errors.width }"
                />
                <span class="suffix">{{ t.cm }}</span>
              </div>
              <div v-if="errors.width" class="error">{{ errors.width }}</div>
            </div>
          </div>

          <!-- Добор -->
          <div class="field">
            <label class="label">{{ t.dob }}</label>
            <input
              v-model="form.dob"
              type="text"
              class="input"
              :placeholder="t.dobPh"
            />
          </div>

          <!-- Приоритеты -->
          <div class="field">
            <label class="label"
              >{{ t.important }} <span class="req">*</span></label
            >
            <div class="hint">{{ t.pick2 }}</div>

            <div class="chips" :class="{ shake: errors.priorities }">
              <button
                v-for="p in priorities"
                :key="p.key"
                type="button"
                class="chip"
                :class="{ active: form.priorities.includes(p.key) }"
                @click="togglePriority(p.key)"
              >
                {{ lang === "ru" ? p.ru : p.uz }}
              </button>
            </div>

            <div v-if="errors.priorities" class="error">
              {{ errors.priorities }}
            </div>
          </div>

          <!-- Телефон -->
          <div class="field">
            <label class="label"
              >{{ t.phone }} <span class="req">*</span></label
            >
            <input
              v-model="form.phone"
              type="tel"
              class="input"
              :placeholder="t.phonePh"
              :class="{ invalid: errors.phone }"
            />
            <div v-if="errors.phone" class="error">{{ errors.phone }}</div>
          </div>

          <button type="submit" class="submit" :disabled="isSubmitting">
            <span v-if="!isSubmitting">{{ t.send }}</span>
            <span v-else>{{ t.sending }}</span>
          </button>
        </form>
      </div>

      <div
        class="toast"
        :class="{ show: toast.show, ok: toast.ok, bad: !toast.ok }"
      >
        {{ toast.text }}
      </div>
    </div>
  </section>
</template>

<style scoped lang="scss">
.lead {
  padding: 60px 0 90px;
  background: #0b0b0c;
  color: #fff;

  opacity: 0;
  transform: translateY(14px);
  transition: 600ms ease;
}
.lead.is-mounted {
  opacity: 1;
  transform: translateY(0);
}

.lead__lang {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 14px;
  opacity: 0;
  transform: translateY(-8px);
  transition: 600ms ease 120ms;
}
.lead.is-mounted .lead__lang {
  opacity: 1;
  transform: translateY(0);
}

.lead__lang-label {
  opacity: 0.75;
  font-weight: 600;
}

.lead__toggle {
  display: inline-flex;
  gap: 6px;
  padding: 4px;
  border-radius: 999px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(10px);
}

.lead__pill {
  padding: 6px 12px;
  border-radius: 999px;
  background: transparent;
  color: #fff;
  border: 0;
  cursor: pointer;
  font-weight: 700;
  transition: 200ms ease;
  opacity: 0.8;
}
.lead__pill.active {
  background: rgba(200, 161, 101, 0.22);
  border: 1px solid rgba(200, 161, 101, 0.45);
  opacity: 1;
}

.lead__card {
  border-radius: 18px;
  padding: 34px;
  background: rgba(255, 255, 255, 0.06);
  border: 1px solid rgba(255, 255, 255, 0.1);
  box-shadow: 0 18px 60px rgba(0, 0, 0, 0.45);
  backdrop-filter: blur(14px);

  opacity: 0;
  transform: translateY(18px) scale(0.99);
  transition: 700ms ease 160ms;
}
.lead.is-mounted .lead__card {
  opacity: 1;
  transform: translateY(0) scale(1);
}

.lead__title {
  font-size: 38px;
  font-weight: 800;
  margin-bottom: 6px;
}
.lead__subtitle {
  opacity: 0.85;
  margin-bottom: 22px;
}

.lead__form {
  display: grid;
  gap: 16px;
}
.field {
  display: grid;
  gap: 8px;
}
.label {
  font-weight: 700;
  opacity: 0.95;
}
.req {
  color: #ff6b6b;
}
.hint {
  opacity: 0.8;
  font-size: 13px;
  margin-top: -4px;
}

.input {
  width: 100%;
  padding: 14px 14px;
  border-radius: 12px;
  background: rgba(0, 0, 0, 0.18);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: #fff;
  outline: none;
  transition: 180ms ease;
}
.input::placeholder {
  color: rgba(255, 255, 255, 0.55);
}
.input:focus {
  border-color: rgba(200, 161, 101, 0.55);
  box-shadow: 0 0 0 4px rgba(200, 161, 101, 0.12);
}
.input.invalid {
  border-color: rgba(255, 107, 107, 0.7);
  box-shadow: 0 0 0 4px rgba(255, 107, 107, 0.12);
}

.grid2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
}
.with-suffix {
  position: relative;
}
.suffix {
  position: absolute;
  right: 12px;
  top: 50%;
  transform: translateY(-50%);
  opacity: 0.7;
  font-weight: 700;
  pointer-events: none;
}

.chips {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.chip {
  padding: 10px 14px;
  border-radius: 999px;
  background: rgba(0, 0, 0, 0.16);
  border: 1px solid rgba(255, 255, 255, 0.1);
  color: #fff;
  cursor: pointer;
  transition: 180ms ease;
  font-weight: 700;
  opacity: 0.92;
}
.chip:hover {
  transform: translateY(-1px);
}
.chip.active {
  background: rgba(200, 161, 101, 0.22);
  border-color: rgba(200, 161, 101, 0.55);
  box-shadow: 0 0 0 4px rgba(200, 161, 101, 0.1);
  opacity: 1;
}

.error {
  font-size: 13px;
  color: #ffb3b3;
}

.submit {
  margin-top: 6px;
  width: 100%;
  padding: 14px 16px;
  border-radius: 12px;
  border: 0;
  cursor: pointer;
  font-weight: 800;
  color: #1b120d;
  background: #c8a165;
  transition: 200ms ease;
}
.submit:hover {
  transform: translateY(-1px);
  opacity: 0.95;
}
.submit:disabled {
  opacity: 0.65;
  cursor: not-allowed;
  transform: none;
}

.toast {
  position: fixed;
  left: 50%;
  bottom: 22px;
  transform: translateX(-50%) translateY(20px);
  opacity: 0;
  padding: 12px 14px;
  border-radius: 12px;
  background: rgba(0, 0, 0, 0.55);
  border: 1px solid rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(12px);
  transition: 250ms ease;
  z-index: 50;
}
.toast.show {
  opacity: 1;
  transform: translateX(-50%) translateY(0);
}

@keyframes shake {
  0%,
  100% {
    transform: translateX(0);
  }
  20% {
    transform: translateX(-6px);
  }
  40% {
    transform: translateX(6px);
  }
  60% {
    transform: translateX(-4px);
  }
  80% {
    transform: translateX(4px);
  }
}
.shake {
  animation: shake 380ms ease;
}

@media (max-width: 900px) {
  .lead__card {
    padding: 26px;
  }
  .lead__title {
    font-size: 32px;
  }
}
@media (max-width: 640px) {
  .lead {
    padding: 40px 0 70px;
  }
  .grid2 {
    grid-template-columns: 1fr;
  }
  .lead__title {
    font-size: 28px;
  }
  .lead__subtitle {
    font-size: 14px;
  }
}
</style>
